#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "BROADCAST script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "BROADCAST ultra script scanning starts"
echo
echo
echo
echo
echo
nmap -Pn $TARGET --script broadcast-ataoe-discover.nse
nmap -Pn $TARGET --script broadcast-avahi-dos.nse
nmap -Pn $TARGET --script broadcast-bjnp-discover.nse
nmap -Pn $TARGET --script broadcast-db2-discover.nse
nmap -Pn $TARGET --script broadcast-dhcp6-discover.nse
nmap -Pn $TARGET --script broadcast-dhcp-discover.nse
nmap -Pn $TARGET --script broadcast-dns-service-discovery.nse
nmap -Pn $TARGET --script broadcast-dropbox-listener.nse
nmap -Pn $TARGET --script broadcast-eigrp-discovery.nse
nmap -Pn $TARGET --script broadcast-igmp-discovery.nse
nmap -Pn $TARGET --script broadcast-listener.nse
nmap -Pn $TARGET --script broadcast-ms-sql-discover.nse
nmap -Pn $TARGET --script broadcast-netbios-master-browser.nse
nmap -Pn $TARGET --script broadcast-networker-discover.nse
nmap -Pn $TARGET --script broadcast-novell-locate.nse
nmap -Pn $TARGET --script broadcast-ospf2-discover.nse
nmap -Pn $TARGET --script broadcast-pc-anywhere.nse
nmap -Pn $TARGET --script broadcast-pc-duo.nse
nmap -Pn $TARGET --script broadcast-pim-discovery.nse
nmap -Pn $TARGET --script broadcast-ping.nse
nmap -Pn $TARGET --script broadcast-pppoe-discover.nse
nmap -Pn $TARGET --script broadcast-rip-discover.nse
nmap -Pn $TARGET --script broadcast-ripng-discover.nse
nmap -Pn $TARGET --script broadcast-sonicwall-discover.nse
nmap -Pn $TARGET --script broadcast-sybase-asa-discover.nse
nmap -Pn $TARGET --script broadcast-tellstick-discover.nse
nmap -Pn $TARGET --script broadcast-upnp-info.nse
nmap -Pn $TARGET --script broadcast-versant-locate.nse
nmap -Pn $TARGET --script broadcast-wake-on-lan.nse
nmap -Pn $TARGET --script broadcast-wpad-discover.nse
nmap -Pn $TARGET --script broadcast-wsdd-discover.nse
nmap -Pn $TARGET --script broadcast-xdmcp-discover.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh