#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "DNS script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "DNS ultra script scanning starts"
echo
echo
echo
echo
echo
nmap $TARGET --script dns-blacklist.nse
nmap $TARGET --script dns-brute.nse
nmap $TARGET --script dns-cache-snoop.nse
nmap $TARGET --script dns-check-zone.nse
nmap $TARGET --script dns-client-subnet-scan.nse
nmap $TARGET --script dns-fuzz.nse
nmap $TARGET --script dns-ip6-arpa-scan.nse
nmap $TARGET --script dns-nsec3-enum.nse
nmap $TARGET --script dns-nsec-enum.nse
nmap $TARGET --script dns-nsid.nse
nmap $TARGET --script dns-random-srcport.nse
nmap $TARGET --script dns-random-txid.nse
nmap $TARGET --script dns-recursion.nse
nmap $TARGET --script dns-service-discovery.nse
nmap $TARGET --script dns-srv-enum.nse
nmap $TARGET --script dns-update.nse
nmap $TARGET --script dns-zeustracker.nse 
nmap $TARGET --script dns-zone-transfer.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh