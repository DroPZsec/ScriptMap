#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "SQL script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "SQL ultra script scanning starts"
echo
echo
echo
echo
echo
nmap $TARGET --script http-sql-injection.nse
nmap $TARGET --script ms-sql-brute.nse
nmap $TARGET --script ms-sql-config.nse
nmap $TARGET --script ms-sql-dac.nse
nmap $TARGET --script ms-sql-dump-hashes.nse
nmap $TARGET --script ms-sql-empty-password.nse
nmap $TARGET --script ms-sql-hasdbaccess.nse
nmap $TARGET --script ms-sql-info.nse
nmap $TARGET --script ms-sql-ntlm-info.nse
nmap $TARGET --script ms-sql-query.nse
nmap $TARGET --script ms-sql-tables.nse
nmap $TARGET --script ms-sql-xp-cmdshell.nse
nmap $TARGET --script mysql-audit.nse
nmap $TARGET --script mysql-brute.nse
nmap $TARGET --script mysql-databases.nse
nmap $TARGET --script mysql-dump-hashes.nse
nmap $TARGET --script mysql-empty-password.nse
nmap $TARGET --script mysql-enum.nse
nmap $TARGET --script mysql-info.nse
nmap $TARGET --script mysql-query.nse
nmap $TARGET --script mysql-users.nse
nmap $TARGET --script mysql-variables.nse
nmap $TARGET --script mysql-vuln-cve2012-2122.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh