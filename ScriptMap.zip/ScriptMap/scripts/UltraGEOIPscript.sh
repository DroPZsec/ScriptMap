#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "GEOIP script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "GEOIP ultra script scanning starts"
echo
echo
echo
echo
echo
nmap $TARGET --script ip-forwarding.nse
nmap $TARGET --script ip-geolocation-geoplugin.nse
nmap $TARGET --script ip-geolocation-ipinfodb.nse
nmap $TARGET --script ip-geolocation-map-bing.nse
nmap $TARGET --script ip-geolocation-map-google.nse
nmap $TARGET --script ip-geolocation-map-kml.nse
nmap $TARGET --script ip-geolocation-maxmind.nse
nmap $TARGET --script ip-https-discover.nse
nmap $TARGET --script ipidseq.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh