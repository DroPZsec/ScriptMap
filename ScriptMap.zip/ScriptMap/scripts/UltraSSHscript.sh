#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "SSH script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "SSH ultra script scanning starts"
echo
echo
echo
echo
echo
nmap $TARGET --script ssh2-enum-algos.nse
nmap $TARGET --script ssh-auth-methods.nse
nmap $TARGET --script ssh-brute.nse
nmap $TARGET --script ssh-hostkey.nse
nmap $TARGET --script ssh-publickey-acceptance.nse
nmap $TARGET --script ssh-run.nse
nmap $TARGET --script sshv1.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh