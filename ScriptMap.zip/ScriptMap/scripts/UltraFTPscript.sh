#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "FTP script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo "FTP ultra script scanning starts"
echo
echo
echo
nmap $TARGET --script ftp-anon.nse
nmap $TARGET --script ftp-bounce.nse
nmap $TARGET --script ftp-brute.nse
nmap $TARGET --script ftp-libopie.nse
nmap $TARGET --script ftp-proftpd-backdoor.nse
nmap $TARGET --script ftp-syst.nse
nmap $TARGET --script ftp-vsftpd-backdoor.nse
nmap $TARGET --script ftp-vuln-cve2010-4221.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh