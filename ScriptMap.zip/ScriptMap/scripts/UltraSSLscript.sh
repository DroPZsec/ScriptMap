#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "SSL script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "SSL ultra script scanning starts"
echo
echo
echo
echo
echo
nmap $TARGET --script ssl-ccs-injection.nse
nmap $TARGET --script ssl-cert-intaddr.nse
nmap $TARGET --script ssl-cert.nse
nmap $TARGET --script ssl-date.nse
nmap $TARGET --script ssl-dh-params.nse
nmap $TARGET --script ssl-enum-ciphers.nse
nmap $TARGET --script ssl-heartbleed.nse
nmap $TARGET --script ssl-known-key.nse
nmap $TARGET --script ssl-poodle.nse
nmap $TARGET --script sslv2-drown.nse
nmap $TARGET --script sslv2.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh