#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "IPv6 script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "IPv6 ultra script scanning starts"
echo
echo
echo
echo
echo
nmap -6 $TARGET --script ipv6-multicast-mld-list.nse
nmap -6 $TARGET --script ipv6-node-info.nse
nmap -6 $TARGET --script ipv6-ra-flood.nse
nmap -6 $TARGET --script targets-ipv6-map4to6.nse
nmap -6 $TARGET --script targets-ipv6-multicast-echo.nse
nmap -6 $TARGET --script targets-ipv6-multicast-invalid-dst.nse
nmap -6 $TARGET --script targets-ipv6-multicast-mld.nse
nmap -6 $TARGET --script targets-ipv6-multicast-slaac.nse
nmap -6 $TARGET --script targets-ipv6-wordlist.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh