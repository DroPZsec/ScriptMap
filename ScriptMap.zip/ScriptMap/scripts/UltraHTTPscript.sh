#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "HTTP script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "HTTP ultra script scanning starts"
echo
echo
echo
echo
echo
nmap $TARGET --script http-adobe-coldfusion-apsa1301.nse
nmap $TARGET --script http-affiliate-id.nse
nmap $TARGET --script http-apache-negotiation.nse
nmap $TARGET --script http-apache-server-status.nse
nmap $TARGET --script http-aspnet-debug.nse
nmap $TARGET --script http-auth-finder.nse
nmap $TARGET --script http-auth.nse
nmap $TARGET --script http-avaya-ipoffice-users.nse
nmap $TARGET --script http-axis2-dir-traversal.nse
nmap $TRAGET --script http-backup-finder.nse
nmap $TARGET --script http-barracuda-dir-traversal.nse
nmap $TARGET --script http-bigip-cookie.nse
nmap $TARGET --script http-brute.nse
nmap $TARGET --script http-cakephp-version.nse
nmap $TARGET --script http-chrono.nse
nmap $TRAGET --script http-cisco-anyconnect.nse
nmap $TARGET --script http-coldfusion-subzero.nse
nmap $TARGET --script http-comments-displayer.nse
nmap $TARGET --script http-config-backup.nse
nmap $TARGET --script http-cookie-flags.nse
nmap $TARGET --script http-cors.nse
nmap $TARGET --script http-cross-domain-policy.nse
nmap $TRAGET --script http-csrf.nse
nmap $TARGET --script http-date.nse
nmap $TARGET --script http-default-accounts.nse
nmap $TARGET --script http-devframework.nse
nmap $TARGET --script http-dlink-backdoor.nse
nmap $TARGET --script http-dombased-xss.nse
nmap $TARGET --script http-domino-enum-passwords.nse
nmap $TARGET --script http-drupal-enum.nse
nmap $TARGET --script http-drupal-enum-users.nse
nmap $TARGET --script http-enum.nse
nmap $TARGET --script http-errors.nse
nmap $TARGET --script http-exif-spider.nse
nmap $TARGET --script http-favicon.nse
nmap $TARGET --script http-feed.nse
nmap $TARGET --script http-fetch.nse
nmap $TARGET --script http-fileupload-exploiter.nse
nmap $TARGET --script http-form-brute.nse
nmap $TARGET --script http-form-fuzzer.nse
nmap $TARGET --script http-frontpage-login.nse
nmap $TARGET --script http-generator.nse
nmap $TARGET --script http-git.nse
nmap $TARGET --script http-gitweb-projects-enum.nse
nmap $TARGET --script http-google-malware.nse
nmap $TARGET --script http-headers.nse
nmap $TARGET --script http-huawei-hg5xx-vuln.nse
nmap $TARGET --script http-icloud-findmyiphone.nse
nmap $TARGET --script http-icloud-sendmsg.nse
nmap $TARGET --script http-iis-short-name-brute.nse
nmap $TARGET --script http-iis-webdav-vuln.nse
nmap $TARGET --script http-internal-ip-disclosure.nse
nmap $TARGET --script http-joomla-brute.nse
nmap $TARGET --script http-jsonp-detection.nse
nmap $TARGET --script http-litespeed-sourcecode-download.nse
nmap $TARGET --script http-ls.nse
nmap $TARGET --script http-majordomo2-dir-traversal.nse
nmap $TARGET --script http-malware-host.nse
nmap $TARGET --script http-mcmp.nse
nmap $TARGET --script http-methods.nse
nmap $TARGET --script http-method-tamper.nse
nmap $TARGET --script http-mobileversion-checker.nse
nmap $TARGET --script http-ntlm-info.nse
nmap $TARGET --script http-open-proxy.nse
nmap $TARGET --script http-open-redirect.nse
nmap $TARGET --script http-passwd.nse
nmap $TARGET --script http-phpmyadmin-dir-traversal.nse
nmap $TARGET --script http-phpself-xss.nse
nmap $TARGET --script http-php-version.nse
nmap $TARGET --script http-proxy-brute.nse
nmap $TARGET --script http-put.nse
nmap $TARGET --script http-qnap-nas-info.nse
nmap $TARGET --script http-referer-checker.nse
nmap $TARGET --script http-rfi-spider.nse
nmap $TARGET --script http-robots.txt.nse
nmap $TARGET --script http-robtex-reverse-ip.nse
nmap $TARGET --script http-robtex-shared-ns.nse
nmap $TARGET --script http-security-headers.nse
nmap $TARGET --script http-server-header.nse
nmap $TARGET --script http-shellshock.nse
nmap $TARGET --script http-sitemap-generator.nse
nmap $TARGET --script http-slowloris-check.nse
nmap $TARGET --script http-sql-injection.nse
nmap $TARGET --script http-stored-xss.nse
nmap $TARGET --script http-svn-enum.nse
nmap $TARGET --script http-svn-info.nse
nmap $TARGET --script http-title.nse
nmap $TARGET --script http-tplink-dir-traversal.nse
nmap $TARGET --script http-trace.nse
nmap $TARGET --script http-traceroute.nse
nmap $TARGET --script http-trane-info.nse
nmap $TARGET --script http-unsafe-output-escaping.nse
nmap $TARGET --script http-useragent-tester.nse
nmap $TARGET --script http-userdir-enum.nse
nmap $TARGET --script http-vhosts.nse
nmap $TARGET --script http-virustotal.nse
nmap $TARGET --script http-vlcstreamer-ls.nse
nmap $TARGET --script http-vmware-path-vuln.nse
nmap $TARGET --script http-waf-detect.nse
nmap $TARGET --script http-waf-fingerprint.nse
nmap $TARGET --script http-webdav-scan.nse
nmap $TARGET --script http-wordpress-brute.nse
nmap $TARGET --script http-wordpress-enum.nse
nmap $TARGET --script http-wordpress-users.nse
nmap $TARGET --script http-xssed.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh