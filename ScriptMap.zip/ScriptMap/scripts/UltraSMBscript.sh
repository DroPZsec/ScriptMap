#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "SMB script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "SMB ultra script scanning starts"
echo
echo
echo
echo
echo
nmap $TARGET -Pn --script samba-vuln-cve-2012-1182.nse
nmap $TARGET -Pn --script smb2-capabilities.nse
nmap $TARGET -Pn --script smb2-security-mode.nse
nmap $TARGET -Pn --script smb2-time.nse
nmap $TARGET -Pn --script smb2-vuln-uptime.nse
nmap $TARGET -Pn --script smb-brute.nse
nmap $TARGET -Pn --script smb-double-pulsar-backdoor.nse 
nmap $TARGET -Pn --script smb-enum-domains.nse
nmap $TARGET -Pn --script smb-enum-groups.nse
nmap $TARGET -Pn --script smb-enum-processes.nse
nmap $TARGET -Pn --script smb-enum-services.nse
nmap $TARGET -Pn --script smb-enum-sessions.nse
nmap $TARGET -Pn --script smb-enum-shares.nse
nmap $TARGET -Pn --script smb-enum-users.nse
nmap $TARGET -Pn --script smb-flood.nse
nmap $TARGET -Pn --script smb-ls.nse
nmap $TARGET -Pn --script smb-mbenum.nse
nmap $TARGET -Pn --script smb-os-discovery.nse
nmap $TARGET -Pn --script smb-print-text.nse
nmap $TARGET -Pn --script smb-protocols.nse
nmap $TARGET -Pn --script smb-psexec.nse
nmap $TARGET -Pn --script smb-security-mode.nse
nmap $TARGET -Pn --script smb-server-stats.nse
nmap $TARGET -Pn --script smb-system-info.nse
nmap $TARGET -Pn --script smb-vuln-conficker.nse
nmap $TARGET -Pn --script smb-vuln-cve2009-3103.nse
nmap $TARGET -Pn --script smb-vuln-cve-2017-7494.nse
nmap $TARGET -Pn --script smb-vuln-ms06-025.nse
nmap $TARGET -Pn --script smb-vuln-ms07-029.nse
nmap $TARGET -Pn --script smb-vuln-ms08-067.nse
nmap $TARGET -Pn --script smb-vuln-ms10-054.nse
nmap $TARGET -Pn --script smb-vuln-ms10-061.nse
nmap $TARGET -Pn --script smb-vuln-ms17-010.nse
nmap $TARGET -Pn --script smb-vuln-regsvc-dos.nse
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh