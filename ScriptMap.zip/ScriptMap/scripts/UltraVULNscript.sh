#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "VULN script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "VULN ultra script scanning starts"
echo
echo
echo
echo
echo
nmap -Pn $TARGET --script vuln
nmap -Pn $TARGET --script smb-vuln-conficker.nse
nmap -Pn $TARGET --script smb-vuln-cve2009-3103.nse
nmap -Pn $TARGET --script smb-vuln-cve-2017-7494.nse
nmap -Pn $TARGET --script smb-vuln-ms06-025.nse
nmap -Pn $TARGET --script smb-vuln-ms07-029.nse
nmap -Pn $TARGET --script smb-vuln-ms08-067.nse
nmap -Pn $TARGET --script smb-vuln-ms10-054.nse
nmap -Pn $TARGET --script smb-vuln-ms10-061.nse
nmap -Pn $TARGET --script smb-vuln-ms17-010.nse
nmap -Pn $TARGET --script smb-vuln-regsvc-dos.nse
nmap -Pn $TARGET --script http-slowloris-check.nse
nmap -Pn $TARGET --script smtp-vuln-cve2010-4344.nse
nmap -Pn $TARGET --script smtp-vuln-cve2011-1720.nse
nmap -Pn $TARGET --script smtp-vuln-cve2011-1764.nse
nmap -Pn $TARGET --script rdp-vuln-ms12-020.nse
nmap -Pn $TARGET --script http-vuln-cve2006-3392.nse
nmap -Pn $TARGET --script http-vuln-cve2009-3960.nse
nmap -Pn $TARGET --script http-vuln-cve2010-0738.nse
nmap -Pn $TARGET --script http-vuln-cve2010-2861.nse
nmap -Pn $TARGET --script http-vuln-cve2011-3192.nse
nmap -Pn $TARGET --script http-vuln-cve2011-3368.nse
nmap -Pn $TARGET --script http-vuln-cve2012-1823.nse
nmap -Pn $TARGET --script http-vuln-cve2013-0156.nse
nmap -Pn $TARGET --script http-vuln-cve2013-6786.nse
nmap -Pn $TARGET --script http-vuln-cve2013-7091.nse
nmap -Pn $TARGET --script http-vuln-cve2014-2126.nse
nmap -Pn $TARGET --script http-vuln-cve2014-2127.nse
nmap -Pn $TARGET --script http-vuln-cve2014-2128.nse
nmap -Pn $TARGET --script http-vuln-cve2014-2129.nse
nmap -Pn $TARGET --script http-vuln-cve2014-3704.nse
nmap -Pn $TARGET --script http-vuln-cve2014-8877.nse
nmap -Pn $TARGET --script http-vuln-cve2015-1427.nse
nmap -Pn $TARGET --script http-vuln-cve2015-1635.nse
nmap -Pn $TARGET --script http-vuln-cve2017-1001000.nse
nmap -Pn $TARGET --script http-vuln-cve2017-5638.nse
nmap -Pn $TARGET --script http-vuln-cve2017-5689.nse
nmap -Pn $TARGET --script http-vuln-cve2017-8917.nse
nmap -Pn $TARGET --script http-vuln-misfortune-cookie.nse
nmap -Pn $TARGET --script http-vuln-wnr1000-creds.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh