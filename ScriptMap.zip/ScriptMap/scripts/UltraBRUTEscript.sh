#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "BRUTE script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "BRUTE ultra script scanning starts"
echo
echo
echo
echo
echo
nmap $TARGET --script afp-brute.nse
nmap $TARGET --script ajp-brute.nse
nmap $TARGET --script backorifice-brute.nse
nmap $TARGET --script cassandra-brute.nse
nmap $TARGET --script cics-user-brute.nse
nmap $TARGET --script citrix-brute-xml.nse
nmap $TARGET --script cvs-brute.nse
nmap $TARGET --script cvs-brute-repository.nse
nmap $TARGET --script deluge-rpc-brute.nse
nmap $TARGET --script dns-brute.nse
nmap $TARGET --script domcon-brute.nse
nmap $TARGET --script dpap-brute.nse
nmap $TARGET --script drda-brute.nse
nmap $TARGET --script ftp-brute.nse
nmap $TARGET --script http-brute.nse
nmap $TARGET --script http-form-brute.nse
nmap $TARGET --script http-iis-short-name-brute.nse
nmap $TARGET --script http-joomla-brute.nse
nmap $TARGET --script http-proxy-brute.nse
nmap $TARGET --script http-wordpress-brute.nse
nmap $TARGET --script iax2-brute.nse
nmap $TARGET --script imap-brute.nse
nmap $TARGET --script informix-brute.nse
nmap $TARGET --script ipmi-brute.nse
nmap $TARGET --script irc-brute.nse
nmap $TARGET --script irc-sasl-brute.nse
nmap $TARGET --script iscsi-brute.nse
nmap $TARGET --script ldap-brute.nse
nmap $TARGET --script membase-brute.nse
nmap $TARGET --script metasploit-msgrpc-brute.nse
nmap $TARGET --script metasploit-xmlrpc-brute.nse
nmap $TARGET --script mikrotik-routeros-brute.nse
nmap $TARGET --script mmouse-brute.nse
nmap $TARGET --script mongodb-brute.nse
nmap $TARGET --script ms-sql-brute.nse
nmap $TARGET --script mysql-brute.nse
nmap $TARGET --script nessus-brute.nse
nmap $TARGET --script nessus-xmlrpc-brute.nse
nmap $TARGET --script netbus-brute.nse
nmap $TARGET --script nexpose-brute.nse
nmap $TARGET --script nje-node-brute.nse
nmap $TARGET --script nje-pass-brute.nse
nmap $TARGET --script nping-brute.nse
nmap $TARGET --script omp2-brute.nse
nmap $TARGET --script openvas-otp-brute.nse
nmap $TARGET --script oracle-brute.nse
nmap $TARGET --script oracle-brute-stealth.nse
nmap $TARGET --script oracle-sid-brute.nse
nmap $TARGET --script pcanywhere-brute.nse
nmap $TARGET --script pgsql-brute.nse
nmap $TARGET --script pop3-brute.nse
nmap $TARGET --script redis-brute.nse
nmap $TARGET --script rexec-brute.nse
nmap $TARGET --script rlogin-brute.nse
nmap $TARGET --script rpcap-brute.nse
nmap $TARGET --script rsync-brute.nse
nmap $TARGET --script rtsp-url-brute.nse
nmap $TARGET --script sip-brute.nse
nmap $TARGET --script smb-brute.nse
nmap $TARGET --script smtp-brute.nse
nmap $TARGET --script snmp-brute.nse
nmap $TARGET --script socks-brute.nse
nmap $TARGET --script ssh-brute.nse
nmap $TARGET --script svn-brute.nse
nmap $TARGET --script telnet-brute.nse
nmap $TARGET --script tso-brute.nse
nmap $TARGET --script vmauthd-brute.nse
nmap $TARGET --script vnc-brute.nse
nmap $TARGET --script xmpp-brute.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh