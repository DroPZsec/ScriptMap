#!/bin/bash
#CodedByvDroPZz
#WhiteSiteHacking
#
#
echo "Ultra NMAP (script) scan Tool"
echo "#WhiteHatSupports"
echo "SMTP script scans"
echo
echo
echo "Type in Target IP:"
read TARGET;
clear
echo
echo
echo
echo "SMTP ultra script scanning starts"
echo
echo
echo
echo
echo
nmap $TARGET --script smtp-brute.nse
nmap $TARGET --script smtp-commands.nse
nmap $TARGET --script smtp-enum-users.nse
nmap $TARGET --script smtp-ntlm-info.nse
nmap $TARGET --script smtp-open-relay.nse
nmap $TARGET --script smtp-strangeport.nse
nmap $TARGET --script smtp-vuln-cve2010-4344.nse
nmap $TARGET --script smtp-vuln-cve2011-1720.nse
nmap $TARGET --script smtp-vuln-cve2011-1764.nse
echo
echo
echo
echo
echo
echo "Thank you for using my tool!"
echo "._____________________________________________."
echo "|#           __            ___ ______        #|"
echo "|  __    __ || *\  _ _    ||*.|     //        |"
echo "| \* \  / / || | ||*//___ | __| __ //__ ____  |"
echo "|  \* \/ /  || | /| || *.||||    //_____/ //_ |"
echo "|   \___/   ||__/ |_||___||_|   //_____/_//__ |"
echo "._____________________________________________."
echo "bye!"
exit
/bin/sh